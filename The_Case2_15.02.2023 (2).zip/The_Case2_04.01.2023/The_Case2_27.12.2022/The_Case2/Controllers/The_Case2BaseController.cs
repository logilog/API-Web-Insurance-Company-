﻿using Microsoft.AspNetCore.Mvc;

namespace The_Case2.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class The_Case2BaseController : Controller
    {

    }
}
