﻿using Business.BusinessProfile;
using Business.Interfaces;
using Entities.BUSINESS;
using Entities.General;
using Entities.REPOSITORY;
using Helpers.Extensions;
using Microsoft.Extensions.Logging;
using Repositories;
using Repositories.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Business
{
    public class ZeylService : IZeylService
    {
        private readonly IZeylRepository _zeylRepository;
        private readonly ILogger<ZeylService> _logger;

        public ZeylService(
            ILogger<ZeylService> Logger,
            IZeylRepository ZeylRepository)
        {
            _logger = Logger;
            _zeylRepository = ZeylRepository;
        }
        public async Task<ResultModel<Zeyl>> Get(Zeyl zeyl)
        {
            ResultModel<Zeyl> Result;
            try
            {
                var dbEntity = BusinessMapper.Mapper.Map<ZeylDTO>(zeyl);
                var DbResult = await _zeylRepository.Get(dbEntity);

                if (!DbResult.Success)
                {
                    _logger.LogWarning(DbResult.ServiceMessage);//Servis mesajını dışarı vermedik sadece log seviyesinde bıraktık
                }

                Result = BusinessMapper.Mapper.Map<ResultModel<Zeyl>>(DbResult);

            }
            catch (System.Exception ex)
            {
                _logger.LogError($"Get {ex.GetErrorDetail()}");
                Result = new ResultModel<Zeyl>(false, "Hata oluştu.");
            }

            return Result;
        }
        public async Task<ResultModel<List<Zeyl>>> GetList()
        {
            ResultModel<List<Zeyl>> Result;
            try
            {
                var DbResult = await _zeylRepository.GetList();

                if (!DbResult.Success)
                {
                    _logger.LogWarning(DbResult.ServiceMessage);//Servis mesajını dışarı vermedik sadece log seviyesinde bıraktık
                }

                Result = BusinessMapper.Mapper.Map<ResultModel<List<Zeyl>>>(DbResult);

            }
            catch (System.Exception ex)
            {
                _logger.LogError($"GetList {ex.GetErrorDetail()}");
                Result = new ResultModel<List<Zeyl>>(false, "Zeyl liste bilgisi alınırken hata oluştu.");
            }

            return Result;
        }
        public async Task<ResultModel<object>> Add(Zeyl zeyl)
        {
            ResultModel<object> Result;
            try
            {
                var dbEntity = BusinessMapper.Mapper.Map<ZeylDTO>(zeyl);
                var DbResult = await _zeylRepository.Add(dbEntity);

                if (!DbResult.Success)
                {
                    _logger.LogWarning(DbResult.ServiceMessage);//Servis mesajını dışarı vermedik sadece log seviyesinde bıraktık
                }

                Result = BusinessMapper.Mapper.Map<ResultModel<object>>(DbResult);


            }
            catch (System.Exception ex)
            {
                _logger.LogError($"Add {ex.GetErrorDetail()}");
                Result = new ResultModel<object>(false, "Hata oluştu.");
            }
            return Result;

        }
    }
}