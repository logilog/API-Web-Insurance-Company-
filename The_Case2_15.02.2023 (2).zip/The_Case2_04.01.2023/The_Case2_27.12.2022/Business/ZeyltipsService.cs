﻿using Business.BusinessProfile;
using Business.Interfaces;
using Entities.BUSINESS;
using Entities.General;
using Entities.REPOSITORY;
using Helpers.Extensions;
using Microsoft.Extensions.Logging;
using Repositories.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Business
{
    public class ZeyltipsService : IZeyltipsService
    {
        private readonly IZeyltipsRepository _zeyltipsRepository;
        private readonly ILogger<ZeyltipsService> _logger;

        public ZeyltipsService(
            ILogger<ZeyltipsService> Logger,
            IZeyltipsRepository ZeyltipsRepository)
        {
            _logger = Logger;
            _zeyltipsRepository = ZeyltipsRepository;
        }
        public async Task<ResultModel<Zeyltips>> Get(Zeyltips zeyltips)
        {
            ResultModel<Zeyltips> Result;
            try
            {
                var dbEntity = BusinessMapper.Mapper.Map<ZeyltipsDTO>(zeyltips);
                var DbResult = await _zeyltipsRepository.Get(dbEntity);

                if (!DbResult.Success)
                {
                    _logger.LogWarning(DbResult.ServiceMessage);//Servis mesajını dışarı vermedik sadece log seviyesinde bıraktık
                }

                Result = BusinessMapper.Mapper.Map<ResultModel<Zeyltips>>(DbResult);

            }
            catch (System.Exception ex)
            {
                _logger.LogError($"Get {ex.GetErrorDetail()}");
                Result = new ResultModel<Zeyltips>(false, "Hata oluştu.");
            }

            return Result;
        }
        public async Task<ResultModel<List<Zeyltips>>> GetList()
        {
            ResultModel<List<Zeyltips>> Result;
            try
            {
                var DbResult = await _zeyltipsRepository.GetList();

                if (!DbResult.Success)
                {
                    _logger.LogWarning(DbResult.ServiceMessage);//Servis mesajını dışarı vermedik sadece log seviyesinde bıraktık
                }

                Result = BusinessMapper.Mapper.Map<ResultModel<List<Zeyltips>>>(DbResult);

            }
            catch (System.Exception ex)
            {
                _logger.LogError($"GetList {ex.GetErrorDetail()}");
                Result = new ResultModel<List<Zeyltips>>(false, "Zeyltips liste bilgisi alınırken hata oluştu.");
            }

            return Result;
        }
        public async Task<ResultModel<object>> Add(Zeyltips zeyltips)
        {
            ResultModel<object> Result;
            try
            {
                var dbEntity = BusinessMapper.Mapper.Map<ZeyltipsDTO>(zeyltips);
                var DbResult = await _zeyltipsRepository.Add(dbEntity);

                if (!DbResult.Success)
                {
                    _logger.LogWarning(DbResult.ServiceMessage);//Servis mesajını dışarı vermedik sadece log seviyesinde bıraktık
                }

                Result = BusinessMapper.Mapper.Map<ResultModel<object>>(DbResult);


            }
            catch (System.Exception ex)
            {
                _logger.LogError($"Add {ex.GetErrorDetail()}");
                Result = new ResultModel<object>(false, "Hata oluştu.");
            }
            return Result;

        }
    }
}