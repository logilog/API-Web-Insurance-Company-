﻿using Business.BusinessProfile;
using Business.Interfaces;
using Entities.BUSINESS;
using Entities.General;
using Entities.REPOSITORY;
using Helpers.Extensions;
using Microsoft.Extensions.Logging;
using Repositories.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Business
{
    public class PersonService : IPersonService
    {
        private readonly IPersonRepository _personRepository;
        private readonly ILogger<PersonService> _logger;

        public PersonService(
            ILogger<PersonService> Logger,
            IPersonRepository PersonRepository)
        {
            _logger = Logger;
            _personRepository = PersonRepository;
        }
        public async Task<ResultModel<person>> Get(person person)
        {
            ResultModel<person> Result;
            try
            {
                var dbEntity = BusinessMapper.Mapper.Map<PersonDTO>(person);
                var DbResult = await _personRepository.Get(dbEntity);

                if (!DbResult.Success)
                {
                    _logger.LogWarning(DbResult.ServiceMessage);//Servis mesajını dışarı vermedik sadece log seviyesinde bıraktık
                }

                Result = BusinessMapper.Mapper.Map<ResultModel<person>>(DbResult);

            }
            catch (System.Exception ex)
            {
                _logger.LogError($"Get {ex.GetErrorDetail()}");
                Result = new ResultModel<person>(false, "Hata oluştu.");
            }

            return Result;
        }
        public async Task<ResultModel<List<person>>> GetList()
        {
            ResultModel<List<person>> Result;
            try
            {
                var DbResult = await _personRepository.GetList();

                if (!DbResult.Success)
                {
                    _logger.LogWarning(DbResult.ServiceMessage);//Servis mesajını dışarı vermedik sadece log seviyesinde bıraktık
                }

                Result = BusinessMapper.Mapper.Map<ResultModel<List<person>>>(DbResult);

            }
            catch (System.Exception ex)
            {
                _logger.LogError($"GetList {ex.GetErrorDetail()}");
                Result = new ResultModel<List<person>>(false, "person liste bilgisi alınırken hata oluştu.");
            }

            return Result;
        }
        public async Task<ResultModel<object>> Add(person person)
        {
            ResultModel<object> Result;
            try
            {
                var dbEntity = BusinessMapper.Mapper.Map<PersonDTO>(person);
                var DbResult = await _personRepository.Add(dbEntity);

                if (!DbResult.Success)
                {
                    _logger.LogWarning(DbResult.ServiceMessage);//Servis mesajını dışarı vermedik sadece log seviyesinde bıraktık
                }

                Result = BusinessMapper.Mapper.Map<ResultModel<object>>(DbResult);


            }
            catch (System.Exception ex)
            {
                _logger.LogError($"Add {ex.GetErrorDetail()}");
                Result = new ResultModel<object>(false, "Hata oluştu.");
            }
            return Result;

        }
    }
}