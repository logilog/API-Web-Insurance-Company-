﻿using Business.BusinessProfile;
using Business.Interfaces;
using Entities.BUSINESS;
using Entities.General;
using Entities.REPOSITORY;
using Helpers.Extensions;
using Microsoft.Extensions.Logging;
using Repositories.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Business
{
    public class KullaniciService : IKullaniciService
    {
        private readonly IKullaniciRepository _kullaniciRepository;
        private readonly ILogger<KullaniciService> _logger;

        public KullaniciService(
            ILogger<KullaniciService> Logger,
            IKullaniciRepository KullaniciRepository)
        {
            _logger = Logger;
            _kullaniciRepository = KullaniciRepository;
        }
        public async Task<ResultModel<kullanici>> Get(kullanici person)
        {
            ResultModel<kullanici> Result;
            try
            {
                var dbEntity = BusinessMapper.Mapper.Map<KullaniciDTO>(person);
                var DbResult = await _kullaniciRepository.Get(dbEntity);

                if (!DbResult.Success)
                {
                    _logger.LogWarning(DbResult.ServiceMessage);//Servis mesajını dışarı vermedik sadece log seviyesinde bıraktık
                }

                Result = BusinessMapper.Mapper.Map<ResultModel<kullanici>>(DbResult);

            }
            catch (System.Exception ex)
            {
                _logger.LogError($"Get {ex.GetErrorDetail()}");
                Result = new ResultModel<kullanici>(false, "Hata oluştu.");
            }

            return Result;
        }
        public async Task<ResultModel<List<kullanici>>> GetList()
        {
            ResultModel<List<kullanici>> Result;
            try
            {
                var DbResult = await _kullaniciRepository.GetList();

                if (!DbResult.Success)
                {
                    _logger.LogWarning(DbResult.ServiceMessage);//Servis mesajını dışarı vermedik sadece log seviyesinde bıraktık
                }

                Result = BusinessMapper.Mapper.Map<ResultModel<List<kullanici>>>(DbResult);

            }
            catch (System.Exception ex)
            {
                _logger.LogError($"GetList {ex.GetErrorDetail()}");
                Result = new ResultModel<List<kullanici>>(false, "Kullanıcı liste bilgisi alınırken hata oluştu.");
            }

            return Result;
        }
        public async Task<ResultModel<object>> Add(kullanici person)
        {
            ResultModel<object> Result;
            try
            {
                var dbEntity = BusinessMapper.Mapper.Map<KullaniciDTO>(person);
                var DbResult = await _kullaniciRepository.Add(dbEntity);

                if (!DbResult.Success)
                {
                    _logger.LogWarning(DbResult.ServiceMessage);//Servis mesajını dışarı vermedik sadece log seviyesinde bıraktık
                }

                Result = BusinessMapper.Mapper.Map<ResultModel<object>>(DbResult);


            }
            catch (System.Exception ex)
            {
                _logger.LogError($"Add {ex.GetErrorDetail()}");
                Result = new ResultModel<object>(false, "Hata oluştu.");
            }
            return Result;

        }
    }
}
