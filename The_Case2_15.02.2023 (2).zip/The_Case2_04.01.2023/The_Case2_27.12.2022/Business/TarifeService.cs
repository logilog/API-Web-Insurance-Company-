﻿using Business.BusinessProfile;
using Business.Interfaces;
using Entities.BUSINESS;
using Entities.General;
using Entities.REPOSITORY;
using Helpers.Extensions;
using Microsoft.Extensions.Logging;
using Repositories.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Business
{
    public class TarifeService : ITarifeService
    {
        private readonly ITarifeRepository _tarifeRepository;
        private readonly ILogger<TarifeService> _logger;

        public TarifeService(
            ILogger<TarifeService> Logger,
            ITarifeRepository TarifeRepository)
        {
            _logger = Logger;
            _tarifeRepository = TarifeRepository;
        }
        public async Task<ResultModel<Tarife>> Get(Tarife tarife)
        {
            ResultModel<Tarife> Result;
            try
            {
                var dbEntity = BusinessMapper.Mapper.Map<TarifeDTO>(tarife);
                var DbResult = await _tarifeRepository.Get(dbEntity);

                if (!DbResult.Success)
                {
                    _logger.LogWarning(DbResult.ServiceMessage);//Servis mesajını dışarı vermedik sadece log seviyesinde bıraktık
                }

                Result = BusinessMapper.Mapper.Map<ResultModel<Tarife>>(DbResult);

            }
            catch (System.Exception ex)
            {
                _logger.LogError($"Get {ex.GetErrorDetail()}");
                Result = new ResultModel<Tarife>(false, "Hata oluştu.");
            }

            return Result;
        }
        public async Task<ResultModel<List<Tarife>>> GetList()
        {
            ResultModel<List<Tarife>> Result;
            try
            {
                var DbResult = await _tarifeRepository.GetList();

                if (!DbResult.Success)
                {
                    _logger.LogWarning(DbResult.ServiceMessage);//Servis mesajını dışarı vermedik sadece log seviyesinde bıraktık
                }

                Result = BusinessMapper.Mapper.Map<ResultModel<List<Tarife>>>(DbResult);

            }
            catch (System.Exception ex)
            {
                _logger.LogError($"GetList {ex.GetErrorDetail()}");
                Result = new ResultModel<List<Tarife>>(false, "Tarife liste bilgisi alınırken hata oluştu.");
            }

            return Result;
        }
        public async Task<ResultModel<object>> Add(Tarife tarife)
        {
            ResultModel<object> Result;
            try
            {
                var dbEntity = BusinessMapper.Mapper.Map<TarifeDTO>(tarife);
                var DbResult = await _tarifeRepository.Add(dbEntity);

                if (!DbResult.Success)
                {
                    _logger.LogWarning(DbResult.ServiceMessage);//Servis mesajını dışarı vermedik sadece log seviyesinde bıraktık
                }

                Result = BusinessMapper.Mapper.Map<ResultModel<object>>(DbResult);


            }
            catch (System.Exception ex)
            {
                _logger.LogError($"Add {ex.GetErrorDetail()}");
                Result = new ResultModel<object>(false, "Hata oluştu.");
            }
            return Result;

        }
    }
}
