﻿using Business.BusinessProfile;
using Business.Interfaces;
using Entities.BUSINESS;
using Entities.General;
using Entities.REPOSITORY;
using Helpers.Extensions;
using Microsoft.Extensions.Logging;
using Repositories.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Business
{
    public class SigortaliService : ISigortaliService
    {
        private readonly ISigortaliRepository _sigortaliRepository;
        private readonly ILogger<SigortaliService> _logger;

        public SigortaliService(
            ILogger<SigortaliService> Logger,
            ISigortaliRepository SigortaliRepository)
        {
            _logger = Logger;
            _sigortaliRepository = SigortaliRepository;
        }
        public async Task<ResultModel<sigortali>> Get(sigortali sigortali)
        {
            ResultModel<sigortali> Result;
            try
            {
                var dbEntity = BusinessMapper.Mapper.Map<SigortaliDTO>(sigortali);
                var DbResult = await _sigortaliRepository.Get(dbEntity);

                if (!DbResult.Success)
                {
                    _logger.LogWarning(DbResult.ServiceMessage);//Servis mesajını dışarı vermedik sadece log seviyesinde bıraktık
                }

                Result = BusinessMapper.Mapper.Map<ResultModel<sigortali>>(DbResult);

            }
            catch (System.Exception ex)
            {
                _logger.LogError($"Get {ex.GetErrorDetail()}");
                Result = new ResultModel<sigortali>(false, "Hata oluştu.");
            }

            return Result;
        }
        public async Task<ResultModel<List<sigortali>>> GetList()
        {
            ResultModel<List<sigortali>> Result;
            try
            {
                var DbResult = await _sigortaliRepository.GetList();

                if (!DbResult.Success)
                {
                    _logger.LogWarning(DbResult.ServiceMessage);//Servis mesajını dışarı vermedik sadece log seviyesinde bıraktık
                }

                Result = BusinessMapper.Mapper.Map<ResultModel<List<sigortali>>>(DbResult);

            }
            catch (System.Exception ex)
            {
                _logger.LogError($"GetList {ex.GetErrorDetail()}");
                Result = new ResultModel<List<sigortali>>(false, "Police liste bilgisi alınırken hata oluştu.");
            }

            return Result;
        }
        public async Task<ResultModel<object>> Add(sigortali sigortali)
        {
            ResultModel<object> Result;
            try
            {
                var dbEntity = BusinessMapper.Mapper.Map<SigortaliDTO>(sigortali);
                var DbResult = await _sigortaliRepository.Add(dbEntity);

                if (!DbResult.Success)
                {
                    _logger.LogWarning(DbResult.ServiceMessage);//Servis mesajını dışarı vermedik sadece log seviyesinde bıraktık
                }

                Result = BusinessMapper.Mapper.Map<ResultModel<object>>(DbResult);


            }
            catch (System.Exception ex)
            {
                _logger.LogError($"Add {ex.GetErrorDetail()}");
                Result = new ResultModel<object>(false, "Hata oluştu.");
            }
            return Result;

        }
    }
}
