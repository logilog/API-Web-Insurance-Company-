﻿namespace TheCase2WebPortal.Helpers
{
    public class ViewModelBase
    {
        public bool Success { get; set; }
        public string Message { get; set; }
    }
}
