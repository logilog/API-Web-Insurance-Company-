﻿namespace TheCase2WebPortal.Models
{
    public class ApiSettings
    {
        public string BaseUrl { get; set; }
    }

}
