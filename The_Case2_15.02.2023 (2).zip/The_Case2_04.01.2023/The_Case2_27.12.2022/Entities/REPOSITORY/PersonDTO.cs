﻿namespace Entities.REPOSITORY
{
    public class PersonDTO
    {
        public int? ID { get; set; }
        public string AD { get; set; }
        public string SOYAD { get; set; }
        public int PID { get; set; }
        public int KIMLIKNO { get; set; }
        public string DOGUMYERI { get; set; }
        public string ULKEUYRUK { get; set; }

    }
}
