﻿namespace Entities.REPOSITORY
{
    public class KullaniciDTO
    {
        public int? ID { get; set; }
        public string AD { get; set; }
        public string SOYAD { get; set; }
        public string KULLANICIADI { get; set; }
        public string SIFRE { get; set; }
        public string AKTIF { get; set; }

    }
}
