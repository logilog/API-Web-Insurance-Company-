﻿namespace Entities.REPOSITORY

{
    public class PoliceDTO
    {
        public int? ID { get; set; }

        public string POLID { get; set; }
        public string SONZEYLNO { get; set; }

        public string BRANSKOD { get; set; }

    }
}
