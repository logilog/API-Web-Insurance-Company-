﻿namespace Entities.REPOSITORY
{
    public class ZeylDTO
    {
        public int? ID { get; set; }

        public string POLID { get; set; }
        public string ZEYLNO { get; set; }
        public string TARIFENO { get; set; }
        public string ZEYLTIP { get; set; }
    }
}
