﻿namespace Entities.REPOSITORY
{
    public class ZeyltipsDTO
    {
        public int? ID { get; set; }

        public string ZEYLTIP { get; set; }
        public string ACIKLAMA { get; set; }
    }
}
