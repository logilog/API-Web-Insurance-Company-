﻿namespace Entities.BUSINESS

{
    public class Tarife
    {
        public int? ID { get; set; }

        public string TARIFENO { get; set; }
        public string UZUNAD { get; set; }
        public string KISAAD { get; set; }


    }
}
