﻿namespace Entities.BUSINESS
{
    public class Police
    {
        public int? ID { get; set; }

        public string POLID { get; set; }
        public string SONZEYLNO { get; set; }

        public string BRANSKOD { get; set; }

    }
}
