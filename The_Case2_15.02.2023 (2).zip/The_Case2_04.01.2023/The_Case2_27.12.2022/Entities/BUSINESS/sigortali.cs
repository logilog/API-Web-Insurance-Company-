﻿namespace Entities.BUSINESS
{
    public class sigortali
    {
        public int? ID { get; set; }

        public string AD { get; set; }
        public string SOYAD { get; set; }

        public int PID { get; set; }
        public int ZEYLNO { get; set; }
        public int POLID { get; set; }
    }
}
