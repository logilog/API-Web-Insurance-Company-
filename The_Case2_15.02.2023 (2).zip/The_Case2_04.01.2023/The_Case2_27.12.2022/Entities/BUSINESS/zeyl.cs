﻿namespace Entities.BUSINESS
{
    public class Zeyl
    {
        public int? ID { get; set; }

        public string POLID { get; set; }
        public string ZEYLNO { get; set; }
        public string TARIFENO { get; set; }
        public string ZEYLTIP { get; set; }
    }
}
