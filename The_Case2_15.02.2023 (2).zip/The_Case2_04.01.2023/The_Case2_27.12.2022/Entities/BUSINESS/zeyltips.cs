﻿namespace Entities.BUSINESS
{
    public class Zeyltips
    {
        public int? ID { get; set; }

        public string ZEYLTIP { get; set; }
        public string ACIKLAMA { get; set; }
    }
}
