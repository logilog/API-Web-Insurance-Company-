﻿using Dapper;
using Entities.General;
using Entities.REPOSITORY;
using Helpers.Extensions;
using MySqlConnector;
using Repositories.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Repositories
{
    public class SigortaliRepository : ISigortaliRepository
    {
        private readonly MySqlConnection _mySqlConnection;
        private readonly RepositoryContext _repositoryContext;
        public SigortaliRepository(MySqlConnection MySqlConnection, RepositoryContext RepositoryContext)
        {
            _mySqlConnection = MySqlConnection;
            _repositoryContext = RepositoryContext;
        }
        public async Task<MiddlewareResult<SigortaliDTO>> Get(SigortaliDTO sigortaliDTO)
        {
            MiddlewareResult<SigortaliDTO> Result = null;
            try
            {
                string sqlcommand = "SELECT ID, AD, SOYAD, ADSOYAD1, PID, ZEYLNO, POLID FROM T_SIGORTALI WHERE ( @ID IS NULL OR ID=@ID ) AND ( @AD IS NULL OR AD=@AD ) AND ( @SOYAD IS NULL OR SOYAD=@SOYAD ) AND ( @ADSOYAD1 IS NULL OR ADSOYAD1=@ADSOYAD1 ) AND ( @PID IS NULL OR PID=@PID ) AND ( @ZEYLNO IS NULL OR ZEYLNO=@ZEYLNO ) AND ( @POLID IS NULL OR POLID=@POLID ) ;";
                using (var connection = _repositoryContext.CreateConnection())
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("@ID", sigortaliDTO.ID);
                    parameters.Add("@AD", sigortaliDTO.AD);
                    parameters.Add("@SOYAD", sigortaliDTO.SOYAD);
                    parameters.Add("@ADSOYAD1", sigortaliDTO.ADSOYAD1);
                    parameters.Add("@PID", sigortaliDTO.PID);
                    parameters.Add("@ZEYLNO", sigortaliDTO.ZEYLNO);
                    parameters.Add("@POLID", sigortaliDTO.POLID);


                    var DbResult = await connection.QuerySingleOrDefaultAsync<SigortaliDTO>(sqlcommand, parameters);
                    if (DbResult == null)
                    {
                        Result = new MiddlewareResult<SigortaliDTO>(false, "Yetkisiz istek", $"SigortaliRepository Get DbResult Null");
                    }
                    else
                    {
                        Result = new MiddlewareResult<SigortaliDTO>(DbResult, DbResult != null);
                    }

                }

            }
            catch (System.Exception ex)
            {
                Result = new MiddlewareResult<SigortaliDTO>(false, "Sigortali bilgisi alınmadı.", $"SigortaliRepository Get {ex.GetErrorDetail()}");
            }
            finally
            {
                if (_mySqlConnection.State == System.Data.ConnectionState.Open)
                {
                    await _mySqlConnection.CloseAsync();
                }
            }
            return Result;
        }
        public async Task<MiddlewareResult<List<SigortaliDTO>>> GetList()
        {
            MiddlewareResult<List<SigortaliDTO>> Result = null;
            try
            {
                string sqlcommand = "SELECT ID, AD, SOYAD, ADSOYAD1, PID, ZEYLNO, POLID FROM T_SIGORTALI;";
                using (var connection = _repositoryContext.CreateConnection())
                {
                    var DbResult = await connection.QueryAsync<SigortaliDTO>(sqlcommand);
                    Result = new MiddlewareResult<List<SigortaliDTO>>(DbResult.ToList());
                }

            }
            catch (System.Exception ex)
            {
                Result = new MiddlewareResult<List<SigortaliDTO>>(false, "Sigortali listesi alınmadı.", $"SigortaliRepository GetList {ex.GetErrorDetail()}");
            }
            finally
            {
                if (_mySqlConnection.State == System.Data.ConnectionState.Open)
                {
                    await _mySqlConnection.CloseAsync();
                }
            }

            return Result;
        }
        public async Task<MiddlewareResult<object>> Add(SigortaliDTO sigortaliDTO)

        {
            MiddlewareResult<object> Result = null;
            try
            {
                string sqlcommand = "INSERT INTO T_SIGORTALI VALUES (@ID, @AD, @SOYAD, @ADSOYAD1, @PID , @ZEYLNO, @POLID )";
                using (var connection = _repositoryContext.CreateConnection())
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("@ID", sigortaliDTO.ID);
                    parameters.Add("@AD", sigortaliDTO.AD);
                    parameters.Add("@SOYAD", sigortaliDTO.SOYAD);
                    parameters.Add("@ADSOYAD1", sigortaliDTO.ADSOYAD1);
                    parameters.Add("@PID", sigortaliDTO.PID);
                    parameters.Add("@ZEYLNO", sigortaliDTO.ZEYLNO);
                    parameters.Add("@POLID", sigortaliDTO.POLID);

                    var DbResult = await connection.ExecuteAsync(sqlcommand, parameters);
                    Result = new MiddlewareResult<object>(DbResult > 0);
                }
            }
            catch (System.Exception ex)
            {
                Result = new MiddlewareResult<object>(false, "Sigortali bilgisi eklenemedi.", $"SigortaliRepository Add {ex.GetErrorDetail()}");
            }
            finally
            {
                if (_mySqlConnection.State == System.Data.ConnectionState.Open)
                {
                    await _mySqlConnection.CloseAsync();
                }
            }

            return Result;
        }
        public bool Update()
        {
            return false;
        }
        public bool Delete()
        {
            return false;
        }
    }
}
