﻿using Dapper;
using Entities.General;
using Entities.REPOSITORY;
using Helpers.Extensions;
using MySqlConnector;
using Repositories.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Repositories
{
    public class KullaniciRepository : IKullaniciRepository
    {
        private readonly MySqlConnection _mySqlConnection;
        private readonly RepositoryContext _repositoryContext;
        public KullaniciRepository(MySqlConnection MySqlConnection, RepositoryContext RepositoryContext)
        {
            _mySqlConnection = MySqlConnection;
            _repositoryContext = RepositoryContext;
        }
        public async Task<MiddlewareResult<KullaniciDTO>> Get(KullaniciDTO personDTO)
        {
            MiddlewareResult<KullaniciDTO> Result = null;
            try
            {
                string sqlcommand = "SELECT ID, AD, SOYAD, KULLANICIADI, SIFRE, AKTIF FROM T_KULLANICI WHERE ( @ID IS NULL OR ID=@ID ) AND ( @AD IS NULL OR AD=@AD ) AND ( @SOYAD IS NULL OR SOYAD=@SOYAD ) AND ( @KULLANICIADI IS NULL OR KULLANICIADI=@KULLANICIADI ) AND ( @SIFRE IS NULL OR SIFRE=@SIFRE ) AND ( @AKTIF IS NULL OR AKTIF=@AKTIF ) ;";
                using (var connection = _repositoryContext.CreateConnection())
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("@ID", personDTO.ID);
                    parameters.Add("@AD", personDTO.AD);
                    parameters.Add("@SOYAD", personDTO.SOYAD);
                    parameters.Add("@KULLANICIADI", personDTO.KULLANICIADI);
                    parameters.Add("@SIFRE", personDTO.SIFRE);
                    parameters.Add("@AKTIF", personDTO.AKTIF);

                    var DbResult = await connection.QuerySingleOrDefaultAsync<KullaniciDTO>(sqlcommand, parameters);
                    if (DbResult == null)
                    {
                        Result = new MiddlewareResult<KullaniciDTO>(false, "Yetkisiz istek", $"SigortaliRepository Get DbResult Null");
                    }
                    else
                    {
                        Result = new MiddlewareResult<KullaniciDTO>(DbResult, DbResult != null);
                    }

                }

            }
            catch (System.Exception ex)
            {
                Result = new MiddlewareResult<KullaniciDTO>(false, "Kullanıcı bilgisi alınmadı.", $"SigortaliRepository Get {ex.GetErrorDetail()}");
            }
            finally
            {
                if (_mySqlConnection.State == System.Data.ConnectionState.Open)
                {
                    await _mySqlConnection.CloseAsync();
                }
            }
            return Result;
        }
        public async Task<MiddlewareResult<List<KullaniciDTO>>> GetList()
        {
            MiddlewareResult<List<KullaniciDTO>> Result = null;
            try
            {
                string sqlcommand = "SELECT ID, AD, SOYAD, KULLANICIADI, SIFRE, AKTIF FROM T_KULLANICI;";
                using (var connection = _repositoryContext.CreateConnection())
                {
                    var DbResult = await connection.QueryAsync<KullaniciDTO>(sqlcommand);
                    Result = new MiddlewareResult<List<KullaniciDTO>>(DbResult.ToList());
                }

            }
            catch (System.Exception ex)
            {
                Result = new MiddlewareResult<List<KullaniciDTO>>(false, "Kullanıcı listesi alınmadı.", $"SigortaliRepository GetList {ex.GetErrorDetail()}");
            }
            finally
            {
                if (_mySqlConnection.State == System.Data.ConnectionState.Open)
                {
                    await _mySqlConnection.CloseAsync();
                }
            }

            return Result;
        }
        public async Task<MiddlewareResult<object>> Add(KullaniciDTO personDTO)

        {
            MiddlewareResult<object> Result = null;
            try
            {
                string sqlcommand = "INSERT INTO T_KULLANICI VALUES (@ID, @AD, @SOYAD, @KULLANICIADI, @SIFRE ,@AKTIF )";
                using (var connection = _repositoryContext.CreateConnection())
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("@ID", personDTO.ID);
                    parameters.Add("@AD", personDTO.AD);
                    parameters.Add("@SOYAD", personDTO.SOYAD);
                    parameters.Add("@KULLANICIADI", personDTO.KULLANICIADI);
                    parameters.Add("@SIFRE", personDTO.SIFRE);
                    parameters.Add("@AKTIF", personDTO.AKTIF);

                    var DbResult = await connection.ExecuteAsync(sqlcommand, parameters);
                    Result = new MiddlewareResult<object>(DbResult > 0);
                }
            }
            catch (System.Exception ex)
            {
                Result = new MiddlewareResult<object>(false, "Kullanıcı bilgisi eklenemedi.", $"SigortaliRepository Add {ex.GetErrorDetail()}");
            }
            finally
            {
                if (_mySqlConnection.State == System.Data.ConnectionState.Open)
                {
                    await _mySqlConnection.CloseAsync();
                }
            }

            return Result;
        }
        public bool Update()
        {
            return false;
        }
        public bool Delete()
        {
            return false;
        }
    }
}
