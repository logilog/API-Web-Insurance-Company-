﻿using Dapper;
using Entities.General;
using Entities.REPOSITORY;
using Helpers.Extensions;
using MySqlConnector;
using Repositories.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Repositories
{
    public class TarifeRepository : ITarifeRepository
    {
        private readonly MySqlConnection _mySqlConnection;
        private readonly RepositoryContext _repositoryContext;
        public TarifeRepository(MySqlConnection MySqlConnection, RepositoryContext RepositoryContext)
        {
            _mySqlConnection = MySqlConnection;
            _repositoryContext = RepositoryContext;
        }
        public async Task<MiddlewareResult<TarifeDTO>> Get(TarifeDTO tarifeDTO)
        {
            MiddlewareResult<TarifeDTO> Result = null;
            try
            {
                string sqlcommand = "SELECT ID, TARIFENO, UZUNAD, KISAAD FROM TARIFE WHERE ( @ID IS NULL OR ID=@ID ) AND ( @TARIFENO IS NULL OR TARIFENO=@TARIFENO ) AND ( @UZUNAD IS NULL OR UZUNAD=@UZUNAD ) AND ( @KISAAD IS NULL OR KISAAD=@KISAAD ) ;";
                using (var connection = _repositoryContext.CreateConnection())
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("@ID", tarifeDTO.ID);
                    parameters.Add("@TARIFENO", tarifeDTO.TARIFENO);
                    parameters.Add("@UZUNAD", tarifeDTO.UZUNAD);
                    parameters.Add("@KISAAD", tarifeDTO.KISAAD);



                    var DbResult = await connection.QuerySingleOrDefaultAsync<TarifeDTO>(sqlcommand, parameters);
                    if (DbResult == null)
                    {
                        Result = new MiddlewareResult<TarifeDTO>(false, "Yetkisiz istek", $"TarifeRepository Get DbResult Null");
                    }
                    else
                    {
                        Result = new MiddlewareResult<TarifeDTO>(DbResult, DbResult != null);
                    }

                }

            }
            catch (System.Exception ex)
            {
                Result = new MiddlewareResult<TarifeDTO>(false, "Tarife bilgisi alınmadı.", $"TarifeRepository Get {ex.GetErrorDetail()}");
            }
            finally
            {
                if (_mySqlConnection.State == System.Data.ConnectionState.Open)
                {
                    await _mySqlConnection.CloseAsync();
                }
            }
            return Result;
        }
        public async Task<MiddlewareResult<List<TarifeDTO>>> GetList()
        {
            MiddlewareResult<List<TarifeDTO>> Result = null;
            try
            {
                string sqlcommand = "SELECT ID, TARIFENO, UZUNAD, KISAAD FROM TARIFE;";
                using (var connection = _repositoryContext.CreateConnection())
                {
                    var DbResult = await connection.QueryAsync<TarifeDTO>(sqlcommand);
                    Result = new MiddlewareResult<List<TarifeDTO>>(DbResult.ToList());
                }

            }
            catch (System.Exception ex)
            {
                Result = new MiddlewareResult<List<TarifeDTO>>(false, "Tarife listesi alınmadı.", $"TarifeRepository GetList {ex.GetErrorDetail()}");
            }
            finally
            {
                if (_mySqlConnection.State == System.Data.ConnectionState.Open)
                {
                    await _mySqlConnection.CloseAsync();
                }
            }

            return Result;
        }
        public async Task<MiddlewareResult<object>> Add(TarifeDTO tarifeDTO)

        {
            MiddlewareResult<object> Result = null;
            try
            {
                string sqlcommand = "INSERT INTO TARIFE VALUES (@ID, @TARIFENO, @UZUNAD, @KISAAD )";
                using (var connection = _repositoryContext.CreateConnection())
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("@ID", tarifeDTO.ID);
                    parameters.Add("@TARIFENO", tarifeDTO.TARIFENO);
                    parameters.Add("@UZUNAD", tarifeDTO.UZUNAD);
                    parameters.Add("@KISAAD", tarifeDTO.KISAAD);

                    var DbResult = await connection.ExecuteAsync(sqlcommand, parameters);
                    Result = new MiddlewareResult<object>(DbResult > 0);
                }
            }
            catch (System.Exception ex)
            {
                Result = new MiddlewareResult<object>(false, "TARIFE bilgisi eklenemedi.", $"TarifeRepository Add {ex.GetErrorDetail()}");
            }
            finally
            {
                if (_mySqlConnection.State == System.Data.ConnectionState.Open)
                {
                    await _mySqlConnection.CloseAsync();
                }
            }

            return Result;
        }
        public bool Update()
        {
            return false;
        }
        public bool Delete()
        {
            return false;
        }
    }
}