﻿using Entities.General;
using Entities.REPOSITORY;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace Repositories.Interfaces
{
    public interface IKullaniciRepository
    {
        public Task<MiddlewareResult<KullaniciDTO>> Get(KullaniciDTO personDTO);
        public Task<MiddlewareResult<List<KullaniciDTO>>> GetList();
        public Task<MiddlewareResult<object>> Add(KullaniciDTO personDTO);

        public bool Update();
        public bool Delete();

    }
}
