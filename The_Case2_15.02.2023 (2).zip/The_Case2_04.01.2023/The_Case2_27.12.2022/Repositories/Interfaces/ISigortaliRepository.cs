﻿using Entities.General;
using Entities.REPOSITORY;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Repositories.Interfaces
{
    public interface ISigortaliRepository
    {
        public Task<MiddlewareResult<SigortaliDTO>> Get(SigortaliDTO sigortaliDTO);
        public Task<MiddlewareResult<List<SigortaliDTO>>> GetList();
        public Task<MiddlewareResult<object>> Add(SigortaliDTO sigortaliDTO);

        public bool Update();
        public bool Delete();
    }
}
