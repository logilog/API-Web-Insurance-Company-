﻿using Entities.General;
using Entities.REPOSITORY;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Repositories.Interfaces
{
    public interface IZeyltipsRepository
    {
        public Task<MiddlewareResult<ZeyltipsDTO>> Get(ZeyltipsDTO zeyltipsDTO); 
        public Task<MiddlewareResult<List<ZeyltipsDTO>>> GetList(); 
        public Task<MiddlewareResult<object>> Add(ZeyltipsDTO zeyltipsDTO);

        public bool Update();
        public bool Delete();
    }
}
