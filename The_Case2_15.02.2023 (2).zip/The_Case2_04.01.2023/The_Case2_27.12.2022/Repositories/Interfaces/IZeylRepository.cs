﻿using Entities.General;
using Entities.REPOSITORY;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Repositories.Interfaces
{
    public interface IZeylRepository
    {
        public Task<MiddlewareResult<ZeylDTO>> Get(ZeylDTO zeylDTO); 
        public Task<MiddlewareResult<List<ZeylDTO>>> GetList(); 
        public Task<MiddlewareResult<object>> Add(ZeylDTO zeylDTO);

        public bool Update();
        public bool Delete();
    }
}
