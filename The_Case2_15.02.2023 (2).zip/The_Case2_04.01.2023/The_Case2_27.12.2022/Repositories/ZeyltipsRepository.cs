﻿using Dapper;
using Entities.General;
using Entities.REPOSITORY;
using Helpers.Extensions;
using MySqlConnector;
using Repositories.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Repositories
{
    public class ZeyltipsRepository : IZeyltipsRepository
    {
        private readonly MySqlConnection _mySqlConnection;
        private readonly RepositoryContext _repositoryContext;
        public ZeyltipsRepository(MySqlConnection MySqlConnection, RepositoryContext RepositoryContext)
        {
            _mySqlConnection = MySqlConnection;
            _repositoryContext = RepositoryContext;
        }
        public async Task<MiddlewareResult<ZeyltipsDTO>> Get(ZeyltipsDTO zeyltipsDTO)
        {
            MiddlewareResult<ZeyltipsDTO> Result = null;
            try
            {
                string sqlcommand = "SELECT ID, ZEYLTIP, ACIKLAMA FROM ZEYLTIPS WHERE ( @ID IS NULL OR ID=@ID ) AND ( @ZEYLTIP IS NULL OR ZEYLTIP=@ZEYLTIP ) AND ( @ACIKLAMA IS NULL OR ACIKLAMA=@ACIKLAMA ) ;";
                using (var connection = _repositoryContext.CreateConnection())
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("@ID", zeyltipsDTO.ID);
                    parameters.Add("@AD", zeyltipsDTO.ZEYLTIP);
                    parameters.Add("@SOYAD", zeyltipsDTO.ACIKLAMA);
                   

                    var DbResult = await connection.QuerySingleOrDefaultAsync<ZeyltipsDTO>(sqlcommand, parameters);
                    if (DbResult == null)
                    {
                        Result = new MiddlewareResult<ZeyltipsDTO>(false, "Yetkisiz istek", $"ZeyltipsRepository Get DbResult Null");
                    }
                    else
                    {
                        Result = new MiddlewareResult<ZeyltipsDTO>(DbResult, DbResult != null);
                    }

                }

            }
            catch (System.Exception ex)
            {
                Result = new MiddlewareResult<ZeyltipsDTO>(false, "Kullanıcı bilgisi alınmadı.", $"ZeyltipsRepository Get {ex.GetErrorDetail()}");
            }
            finally
            {
                if (_mySqlConnection.State == System.Data.ConnectionState.Open)
                {
                    await _mySqlConnection.CloseAsync();
                }
            }
            return Result;
        }
        public async Task<MiddlewareResult<List<ZeyltipsDTO>>> GetList()
        {
            MiddlewareResult<List<ZeyltipsDTO>> Result = null;
            try
            {
                string sqlcommand = "SELECT ID, ZEYLTIP, ACIKLAMA FROM ZEYLTIPS; ";
                using (var connection = _repositoryContext.CreateConnection())
                {
                    var DbResult = await connection.QueryAsync<ZeyltipsDTO>(sqlcommand);
                    Result = new MiddlewareResult<List<ZeyltipsDTO>>(DbResult.ToList());
                }

            }
            catch (System.Exception ex)
            {
                Result = new MiddlewareResult<List<ZeyltipsDTO>>(false, "Zeyltips listesi alınmadı.", $"ZeyltipsRepository GetList {ex.GetErrorDetail()}");
            }
            finally
            {
                if (_mySqlConnection.State == System.Data.ConnectionState.Open)
                {
                    await _mySqlConnection.CloseAsync();
                }
            }

            return Result;
        }
        public async Task<MiddlewareResult<object>> Add(ZeyltipsDTO zeyltipsDTO)

        {
            MiddlewareResult<object> Result = null;
            try
            {
                string sqlcommand = "INSERT INTO ZEYLTIPS VALUES (@ID, @ZEYLTIP, @ACIKLAMA )";
                using (var connection = _repositoryContext.CreateConnection())
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("@ID", zeyltipsDTO.ID);
                    parameters.Add("@AD", zeyltipsDTO.ZEYLTIP);
                    parameters.Add("@SOYAD", zeyltipsDTO.ACIKLAMA);

                    var DbResult = await connection.ExecuteAsync(sqlcommand, parameters);
                    Result = new MiddlewareResult<object>(DbResult > 0);
                }
            }
            catch (System.Exception ex)
            {
                Result = new MiddlewareResult<object>(false, " Zeyltips bilgisi eklenemedi.", $"ZeyltipsRepository Add {ex.GetErrorDetail()}");
            }
            finally
            {
                if (_mySqlConnection.State == System.Data.ConnectionState.Open)
                {
                    await _mySqlConnection.CloseAsync();
                }
            }

            return Result;
        }
        public bool Update()
        {
            return false;
        }
        public bool Delete()
        {
            return false;
        }
    }
}

