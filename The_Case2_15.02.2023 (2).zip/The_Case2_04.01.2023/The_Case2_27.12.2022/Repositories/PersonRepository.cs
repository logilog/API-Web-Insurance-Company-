﻿using Dapper;
using Entities.General;
using Entities.REPOSITORY;
using Helpers.Extensions;
using MySqlConnector;
using Repositories.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Repositories
{
    public class PersonRepository : IPersonRepository
    {
        private readonly MySqlConnection _mySqlConnection;
        private readonly RepositoryContext _repositoryContext;
        public PersonRepository(MySqlConnection MySqlConnection, RepositoryContext RepositoryContext)
        {
            _mySqlConnection = MySqlConnection;
            _repositoryContext = RepositoryContext;
        }
        public async Task<MiddlewareResult<PersonDTO>> Get(PersonDTO personDTO)
        {
            MiddlewareResult<PersonDTO> Result = null;
            try
            {
                string sqlcommand = "SELECT ID, AD, SOYAD, PID, KIMLIKNO, DOGUMYERI, ULKEUYRUK FROM T_PERSON WHERE ( @ID IS NULL OR ID=@ID ) AND ( @AD IS NULL OR AD=@AD ) AND ( @SOYAD IS NULL OR SOYAD=@SOYAD ) AND ( @PID IS NULL OR PID=@PID ) AND ( @KIMLIKNO IS NULL OR KIMLIKNO=@KIMLIKNO) AND ( @DOGUMYERI IS NULL OR DOGUMYERI=@DOGUMYERI) AND  ( @ULKEUYRUK IS NULL OR ULKEUYRUK=@ULKEUYRUK );";
                using (var connection = _repositoryContext.CreateConnection())
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("@ID", personDTO.ID);
                    parameters.Add("@AD", personDTO.AD);
                    parameters.Add("@SOYAD", personDTO.SOYAD);
                    parameters.Add("@PID", personDTO.PID);
                    parameters.Add("@KIMLIKNO", personDTO.KIMLIKNO);
                    parameters.Add("@DOGUMYERI", personDTO.DOGUMYERI);
                    parameters.Add("@ULKEUYRUK", personDTO.ULKEUYRUK);


                    var DbResult = await connection.QuerySingleOrDefaultAsync<PersonDTO>(sqlcommand, parameters);
                    if (DbResult == null)
                    {
                        Result = new MiddlewareResult<PersonDTO>(false, "Yetkisiz istek", $"PersonRepository Get DbResult Null");
                    }
                    else
                    {
                        Result = new MiddlewareResult<PersonDTO>(DbResult, DbResult != null);
                    }

                }

            }
            catch (System.Exception ex)
            {
                Result = new MiddlewareResult<PersonDTO>(false, "Person bilgisi alınmadı.", $"PersonRepository Get {ex.GetErrorDetail()}");
            }
            finally
            {
                if (_mySqlConnection.State == System.Data.ConnectionState.Open)
                {
                    await _mySqlConnection.CloseAsync();
                }
            }
            return Result;
        }
        public async Task<MiddlewareResult<List<PersonDTO>>> GetList()
        {
            MiddlewareResult<List<PersonDTO>> Result = null;
            try
            {
                string sqlcommand = "SELECT ID, AD, SOYAD, PID, KIMLIKNO, DOGUMYERI, ULKEUYRUK FROM T_PERSON;";
                using (var connection = _repositoryContext.CreateConnection())
                {
                    var DbResult = await connection.QueryAsync<PersonDTO>(sqlcommand);
                    Result = new MiddlewareResult<List<PersonDTO>>(DbResult.ToList());
                }

            }
            catch (System.Exception ex)
            {
                Result = new MiddlewareResult<List<PersonDTO>>(false, "Person listesi alınmadı.", $"PersonRepository GetList {ex.GetErrorDetail()}");
            }
            finally
            {
                if (_mySqlConnection.State == System.Data.ConnectionState.Open)
                {
                    await _mySqlConnection.CloseAsync();
                }
            }

            return Result;
        }

        public async Task<MiddlewareResult<object>> Add(PersonDTO personDTO)

        {
            MiddlewareResult<object> Result = null;
            try
            {
                string sqlcommand = "INSERT INTO T_PERSON VALUES (@ID, @AD, @SOYAD, @DOGUMYERI, @PID ,@KIMLIKNO,@ULKEUYRUK )";
                using (var connection = _repositoryContext.CreateConnection())
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("@ID", personDTO.ID);
                    parameters.Add("@AD", personDTO.AD);
                    parameters.Add("@SOYAD", personDTO.SOYAD);
                    parameters.Add("@DOGUMYERI", personDTO.DOGUMYERI);
                    parameters.Add("@PID", personDTO.PID);
                    parameters.Add("@KIMLIKNO", personDTO.KIMLIKNO);
                    parameters.Add("@ULKEUYRUK", personDTO.ULKEUYRUK);


                    var DbResult = await connection.ExecuteAsync(sqlcommand, parameters);
                    Result = new MiddlewareResult<object>(DbResult > 0);
                }
            }
            catch (System.Exception ex)
            {
                Result = new MiddlewareResult<object>(false, "PERSON bilgisi eklenemedi.", $"PersonRepository Add {ex.GetErrorDetail()}");
            }
            finally
            {
                if (_mySqlConnection.State == System.Data.ConnectionState.Open)
                {
                    await _mySqlConnection.CloseAsync();
                }
            }

            return Result;
        }
        public bool Update()
        {
            return false;
        }
        public bool Delete()
        {
            return false;
        }
    }
}
